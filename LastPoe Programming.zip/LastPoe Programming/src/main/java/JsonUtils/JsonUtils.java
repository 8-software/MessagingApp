package com.mycompany.lastpoe;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class JsonUtils {

    public static List<String> readMessagesFromJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                System.out.println("File not found: " + filePath);
                return List.of();
            }
            return mapper.readValue(file, new TypeReference<List<String>>() {});
        } catch (IOException e) {
            e.printStackTrace();
            return List.of();
        }
    }
}
